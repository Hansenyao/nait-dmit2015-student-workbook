#set($modelInstanceName = $ModelClass.substring(0, 1).toLowerCase() + $ModelClass.substring(1))
#set($cdiInstanceName = "jakartaPersistence" + $ModelClass + "Service" )
#set($collectionInstanceName = $ModelClass.substring(0, 1).toLowerCase() + $ModelClass.substring(1) + "s")
#set($currentModelInstance = "current" + $ModelClass )

import dmit2015.model.${ModelClass};
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

import java.util.random.RandomGenerator;

@Named("${cdiInstanceName}")
@ApplicationScoped
public class JakartaPersistence${ModelClass}Service implements ${ModelClass}Service {

     // Assign a unitName if there are more than one persistence unit defined in persistence.xml
    @PersistenceContext //(unitName="pu-name-in-persistence.xml")
    private EntityManager entityManager;

    @Override
    @Transactional
    public ${ModelClass} create${ModelClass}(${ModelClass} ${modelInstanceName}) {
        // If the primary key is not an identity column then write code below here to
        // 1) Generate a new primary key value
        // 2) Set the primary key value for the new entity

        entityManager.persist(${modelInstanceName});
        return ${modelInstanceName};
    }

    @Override
    public Optional<${ModelClass}> get${ModelClass}ById(${PrimaryKeyDataType} $primaryKey) {
       try {
            ${ModelClass} querySingleResult = entityManager.find(${ModelClass}.class, $primaryKey);
            if (querySingleResult != null) {
                return Optional.of(querySingleResult);
            }
        } catch (Exception ex) {
            // $primaryKey value not found
            throw new RuntimeException(ex);
        }
        return Optional.empty();
    }

    @Override
    public List<${ModelClass}> getAll${ModelClass}s() {
        return entityManager.createQuery("SELECT o FROM ${ModelClass} o ", ${ModelClass}.class)
                .getResultList();
    }

    @Override
    @Transactional
    public ${ModelClass} update${ModelClass}(${ModelClass} ${modelInstanceName}) {

        Optional<${ModelClass}> optional${ModelClass} = get${ModelClass}ById(${modelInstanceName}.getId());
        if (optional${ModelClass}.isEmpty()) {
            String errorMessage = String.format("The id %s does not exists in the system.", ${modelInstanceName}.getId());
            throw new RuntimeException(errorMessage);
        } else {
             var existing${ModelClass} = optional${ModelClass}.orElseThrow();
             // Update only properties that is editable by the end user
             // TODO: Copy each edit property from ${modelInstanceName} to existing${ModelClass}
             // existing${ModelClass}.setPropertyName(${modelInstanceName}.getPropertyName());

            ${modelInstanceName} = entityManager.merge(existing${ModelClass});
        }
        return ${modelInstanceName};
    }

    @Override
    @Transactional
    public void delete${ModelClass}ById(${PrimaryKeyDataType} $primaryKey) {
        Optional<${ModelClass}> optional${ModelClass} = get${ModelClass}ById(${primaryKey});
        if (optional${ModelClass}.isPresent()) {
            ${ModelClass} ${modelInstanceName} = optional${ModelClass}.orElseThrow();
             // Write code to throw a RuntimeException if this entity contains child records
           entityManager.remove(${modelInstanceName});
        } else {
            throw new RuntimeException("Could not find ${ModelClass} with id: " + id);
        }
    }

}