#set($entityInstance = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) )
#set($serviceInstanceName = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "Service")
#set($primaryKey = $entityInstance + "Id")

import dmit2015.model.${EntityName};
import net.datafaker.Faker;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.fail;

/**
If your current development environment is using Podman instead of Docker 
you can perform the following one-time setup to use Testcontainer with podman instead of docker.

From a Terminal window type the following commands:
# 1) Install
sudo apt update
sudo apt install -y podman-docker podman-remote  # podman-docker provides 'docker' CLI shim

# 2) Enable the user socket (rootless)
systemctl --user enable --now podman.socket

# 3) Point Docker API to Podman’s socket (add to ~/.bashrc or ~/.zshrc)
echo 'export DOCKER_HOST=unix:///run/user/$UID/podman/podman.sock' >> ~/.profile
source ~/.profile

# 4) Quick sanity check (either works)
docker info        # should print info mentioning Podman
podman-remote info # also OK

# 5) Logout then login for changes to `~/.profile` to take effect.

To use Testcontainer verify that your Maven `pom.xml` file includes the following dependencies:

        <dependency>
            <groupId>jakarta.persistence</groupId>
            <artifactId>jakarta.persistence-api</artifactId>
            <version>3.2.0</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>jakarta.transaction</groupId>
            <artifactId>jakarta.transaction-api</artifactId>
            <version>2.0.1</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.hibernate.validator</groupId>
            <artifactId>hibernate-validator</artifactId>
            <version>9.0.1.Final</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.glassfish</groupId>
            <artifactId>jakarta.el</artifactId>
            <version>4.0.2</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>1.20.3</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>postgresql</artifactId>
            <version>1.20.3</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>42.7.7</version>
            <scope>test</scope>
        </dependency>
*/

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Testcontainers
public class JakartaPersistence${EntityName}ServiceImplementationTestContainerIT {

    private static final Faker faker = new Faker();
    private static final String TEST_PU_NAME = "${ResourceLocalPersistenceUnit}"; // PU name used for tests (RESOURCE_LOCAL)

    @Container
    static PostgreSQLContainer<?> db =
        new PostgreSQLContainer<>("postgres:16-alpine")
            // .withReuse(true) // uncomment if you enable reuse in ~/.testcontainers.properties
            .withDatabaseName("dmit2015")
            .withUsername("user2015")
            .withPassword("Password2015");

    private EntityManagerFactory emf;
    private EntityManager em;

    // Service under test: requires a testing constructor that accepts EntityManager
    private JakartaPersistence${EntityName}Service ${serviceInstanceName};

    @BeforeAll
    void beforeAll() {
        // Boot JPA in-process with JDBC settings from the running container
        Map<String, Object> overrides = new HashMap<>();
        overrides.put("jakarta.persistence.jdbc.url", db.getJdbcUrl());
        overrides.put("jakarta.persistence.jdbc.user", db.getUsername());
        overrides.put("jakarta.persistence.jdbc.password", db.getPassword());
        overrides.put("jakarta.persistence.jdbc.driver", "org.postgresql.Driver");

        // Reasonable defaults for tests (feel free to adjust)
        overrides.put("hibernate.hbm2ddl.auto", "update");
        overrides.put("hibernate.show_sql", "false");
        overrides.put("hibernate.format_sql", "true");
        overrides.put("jakarta.persistence.validation.mode", "AUTO");

        emf = Persistence.createEntityManagerFactory(TEST_PU_NAME, overrides);
    }

    @AfterAll
    void afterAll() {
        if (emf != null) {
            emf.close();
        }
    }

    @BeforeEach
    void beforeEach() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
        // IMPORTANT: your service class must have a constructor that accepts EntityManager for tests
        ${serviceInstanceName} = new JakartaPersistence${EntityName}Service(em);
    }

    @AfterEach
    void afterEach() {
        if (em != null) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback(); 
            }
            em.close();
        }
    }

    @Order(1)
    @Test
    void givenNew${EntityName}_whenAdd${EntityName}_then${EntityName}IsAdded() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);

        // Act
        ${serviceInstanceName}.create${EntityName}(new${EntityName});

        // Assert
        assertThat(new${EntityName}.getId()).isNotNull();
    }

    @Order(2)
    @Test
    void givenExistingId_whenFindById_thenReturnEntity() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);

        // Act
        new${EntityName} = ${serviceInstanceName}.create${EntityName}(new${EntityName});

        // Assert
        Optional<${EntityName}> optional${EntityName} =
            ${serviceInstanceName}.get${EntityName}ById(new${EntityName}.getId());
        assertThat(optional${EntityName}).isPresent();

        var existing${EntityName} = optional${EntityName}.orElseThrow();
        assertThat(existing${EntityName})
            .usingRecursiveComparison()
            // .ignoringFields("field1", "field2")
            .isEqualTo(new${EntityName});
    }

    @Order(3)
    @Test
    void givenExistingEntity_whenUpdated${EntityName}_then${EntityName}IsUpdated() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);
        new${EntityName} = ${serviceInstanceName}.create${EntityName}(new${EntityName});

        // TODO: change values of relevant properties
        // new${EntityName}.setProperty1(faker.lorem().word());
        // new${EntityName}.setProperty2(faker.lorem().word());

        // Act
        ${EntityName} updated${EntityName} = ${serviceInstanceName}.update${EntityName}(new${EntityName});

        // Assert
        Optional<${EntityName}> optional${EntityName} =
            ${serviceInstanceName}.get${EntityName}ById(updated${EntityName}.getId());
        assertThat(optional${EntityName}).isPresent();

        var existing${EntityName} = optional${EntityName}.orElseThrow();
        assertThat(existing${EntityName})
            .usingRecursiveComparison()
            // .ignoringFields("field1", "field2")
            .isEqualTo(new${EntityName});
    }

    @Order(4)
    @Test
    void givenExistingId_whenDelete${EntityName}_then${EntityName}IsDeleted() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);
        new${EntityName} = ${serviceInstanceName}.create${EntityName}(new${EntityName});

        // Act
        ${serviceInstanceName}.delete${EntityName}ById(new${EntityName}.getId());

        // Assert
        Optional<${EntityName}> optional${EntityName} =
            ${serviceInstanceName}.get${EntityName}ById(new${EntityName}.getId());
        assertThat(optional${EntityName}).isEmpty();
    }

    @Order(5)
    @ParameterizedTest
    @CsvSource({"10"})
    void givenMultipleEntity_whenFindAll_thenReturnEntityList(int expectedRecordCount) {
        // Arrange
        assertThat(${serviceInstanceName}).isNotNull();
        ${serviceInstanceName}.deleteAll${EntityName}s();

        ${EntityName} firstExpected${EntityName} = null;
        ${EntityName} lastExpected${EntityName} = null;

        for (int i = 1; i <= expectedRecordCount; i++) {
            ${EntityName} current${EntityName} = ${EntityName}.of(faker);
            if (i == 1) firstExpected${EntityName} = current${EntityName};
            if (i == expectedRecordCount) lastExpected${EntityName} = current${EntityName};
            ${serviceInstanceName}.create${EntityName}(current${EntityName});
        }

        // Act
        List<${EntityName}> ${entityInstance}List = ${serviceInstanceName}.getAll${EntityName}s();

        // Assert
        assertThat(${entityInstance}List).hasSize(expectedRecordCount);

        var firstActual${EntityName} = ${entityInstance}List.getFirst();
        var lastActual${EntityName}  = ${entityInstance}List.getLast();

        assertThat(firstActual${EntityName})
            .usingRecursiveComparison()
            .isEqualTo(firstExpected${EntityName});
        assertThat(lastActual${EntityName})
            .usingRecursiveComparison()
            .isEqualTo(lastExpected${EntityName});
    }

    @Order(6)
    @ParameterizedTest
    // TODO: Change values below to match your entity's validation constraints
    @CsvSource(value = {
        "InvalidProp1, Prop2, Prop3, ExpectedExceptionMessage",
        "Prop1, InvalidProp2, Prop3, ExpectedExceptionMessage",
    }, nullValues = {"null"})
    void givenEntityWithValidationErrors_whenAdd${EntityName}_thenThrowException(
        String property1,
        String property2,
        String property3,
        String expectedExceptionMessage
    ) {
        // Arrange
        ${EntityName} new${EntityName} = new ${EntityName}();
        // new${EntityName}.setProperty1(property1);
        // new${EntityName}.setProperty2(property2);
        // new${EntityName}.setProperty3(property3);

        try {
            // Act
            ${serviceInstanceName}.create${EntityName}(new${EntityName});
            fail("A bean validation constraint should have been thrown");
        } catch (Exception ex) {
            // Assert
            assertThat(ex).hasMessageContaining(expectedExceptionMessage);
        }
    }
}
