#set($modelInstanceName = $ModelClass.substring(0, 1).toLowerCase() + $ModelClass.substring(1))

import dmit2015.model.${ModelClass};

import java.util.List;
import java.util.Optional;

public interface ${ModelClass}Service {

    ${ModelClass} create${ModelClass}(${ModelClass} ${modelInstanceName});

    Optional<${ModelClass}> get${ModelClass}ById(${IdDataType} id);

    List<${ModelClass}> getAll${ModelClass}s();

    ${ModelClass} update${ModelClass}(${ModelClass} ${modelInstanceName});

    void delete${ModelClass}ById(${IdDataType} id);
}