#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")
package ${PACKAGE_NAME};#end

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@Named("${BEAN_NAME}")
@RequestScoped
public class ${CLASS_NAME} {

    private String userInput;

    public String getUserInput() {
        return userInput;
    }

    public void setUserInput(String userInput) {
        this.userInput = userInput;
    }

    public String getMessage() {
        return "Hello, " + userInput;
    }

    public String submit() {
        // TODO: Add your business logic here
        return null; // or navigation outcome
    }
}