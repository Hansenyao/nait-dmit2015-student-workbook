import jakarta.inject.Inject;
import jakarta.interceptor.AroundInvoke;
import jakarta.interceptor.InvocationContext;
import jakarta.security.enterprise.SecurityContext;

public class ${EntityName}SecurityInterceptor {

    @Inject
    private SecurityContext _securityContext;

    @AroundInvoke
    public Object verifyAccess(InvocationContext ic) throws Exception {
        String methodName = ic.getMethod().getName();

        // TODO: Change the method name to intercept
        if (methodName.startsWith("methdoName") ) {
            // TODO: Change the role to check
            boolean isInRole = _securityContext.isCallerInRole("RoleToBeIn");
            if (! isInRole) {
                throw new RuntimeException("Access denied. You do not have permission to execute this method.");
            }
        }

        return ic.proceed();
    }
}