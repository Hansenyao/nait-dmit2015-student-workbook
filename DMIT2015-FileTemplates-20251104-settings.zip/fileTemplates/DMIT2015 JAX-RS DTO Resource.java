#set($entityInstance = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) )
#set($repositoryName = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "Repository")
#set($primaryKeyGetter = "get" + $primaryKeyField.substring(0, 1).toUpperCase() + $primaryKeyField.substring(1) + "()")
#set($DtoClass = $EntityName + "Dto" )
#set($EntityMapper = $EntityName + "Mapper")
#set($findAllMethodName = "findAll" + $EntityName + "s")
#set($createMethodName = "create" + $EntityName)
#set($updateMethodName = "update" + $EntityName)
#set($deleteMethodName = "delete" + $EntityName)
#set($findByIdMethodName = "find" + $EntityName + "ById")

import common.validation.JavaBeanValidator;
import dmit2015.entity.${EntityName};
import dmit2015.dto.$DtoClass;
import dmit2015.mapper.${EntityMapper};
import dmit2015.repository.${EntityName}Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.OptimisticLockException;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;

import java.net.URI;
import java.util.stream.Collectors;

/**
 * This Jakarta RESTful Web Services root resource class provides common REST API endpoints to
 * perform CRUD operations on the DTO (Data Transfer Object) for a Jakarta Persistence entity.
 */
@ApplicationScoped
@Path("${EntityName}Dtos")	            // All methods in this class are associated this URL path
@Consumes(MediaType.APPLICATION_JSON)	// All methods in this class expects method parameters to contain data in JSON format
@Produces(MediaType.APPLICATION_JSON)	// All methods in this class returns data in JSON format
public class ${EntityName}DtoResource {

    @Inject
    private ${EntityName}Repository ${repositoryName};

    @GET	// This method only accepts HTTP GET requests.
    public Response ${findAllMethodName}${EntityName}s() {
        return Response.ok(
            ${repositoryName}
                .findAll()
                .stream()
                .map(${EntityMapper}.INSTANCE::toDto)
                .collect(Collectors.toList())
            ).build();
    }

    @Path("{id}")
    @GET	// This method only accepts HTTP GET requests.
    public Response ${findByIdMethodName}${EntityName}ById(@PathParam("id") ${PrimaryKeyDataType} ${primaryKeyField}) {
       ${EntityName} existing${EntityName} = ${repositoryName}.findById(${primaryKeyField}).orElseThrow(NotFoundException::new);

       ${DtoClass} dto = ${EntityMapper}.INSTANCE.toDto(existing${EntityName});

       return Response.ok(dto).build();
    }

    @POST	// This method only accepts HTTP POST requests.
    public Response ${createMethodName}${EntityName}(${DtoClass} dto, @Context UriInfo uriInfo) {
        ${EntityName} new${EntityName} = ${EntityMapper}.INSTANCE.toEntity(dto);

        String errorMessage = JavaBeanValidator.validateBean(new${EntityName});
        if (errorMessage != null) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(errorMessage)
                    .build();
        }

        try {
            // Persist the new ${EntityName} into the database
            ${repositoryName}.add(new${EntityName});
        } catch (Exception ex) {
            // Return a HTTP status of "500 Internal Server Error" containing the exception message
            return Response.
                    serverError()
                    .entity(ex.getMessage())
                    .build();
        }

        // uriInfo is injected via @Context parameter to this method
        URI location = UriBuilder
                .fromPath(uriInfo.getPath())
                .path("{id}")
                .build(new${EntityName}.${primaryKeyGetter});

        // Set the location path of the new entity with its identifier
        // Returns an HTTP status of "201 Created" if the ${EntityName} was created.
        return Response
                .created(location)
                .build();
    }

    @PUT 			// This method only accepts HTTP PUT requests.
    @Path("{id}")	// This method accepts a path parameter and gives it a name of id
    public Response ${updateMethodName}${EntityName}(@PathParam("id") ${PrimaryKeyDataType} id, ${DtoClass} dto) {
        if (!id.equals(dto.${primaryKeyGetter})) {
            throw new BadRequestException();
        }

        ${EntityName} existing${EntityName} = ${repositoryName}
                .findById(id)
                .orElseThrow(NotFoundException::new);

        ${EntityName} updated${EntityName} = ${EntityMapper}.INSTANCE.toEntity(dto);

        String errorMessage = JavaBeanValidator.validateBean(updated${EntityName});
        if (errorMessage != null) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(errorMessage)
                    .build();
        }

        // TODO: copy properties from the updated entity to the existing entity such as copy the version property shown below
        existing${EntityName}.setVersion(updated${EntityName}.getVersion());

        try {
            ${repositoryName}.update(existing${EntityName});
        } catch (OptimisticLockException ex) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("The data you are trying to update has changed since your last read request.")
                    .build();
        } catch (Exception ex) {
            // Return an HTTP status of "500 Internal Server Error" containing the exception message
            return Response.
                    serverError()
                    .entity(ex.getMessage())
                    .build();
        }

        // Returns an HTTP status "200 OK" and include in the body of the response the object that was updated
        ${DtoClass} updatedDto = ${EntityMapper}.INSTANCE.toDto(existing${EntityName});
        return Response.ok(updatedDto).build();
    }

    @DELETE 			// This method only accepts HTTP DELETE requests.
    @Path("{id}")	// This method accepts a path parameter and gives it a name of id
    public Response ${deleteMethodName}${EntityName}(@PathParam("id") ${PrimaryKeyDataType} ${primaryKeyField}) {

        ${EntityName} existing${EntityName} = ${repositoryName}
                .findById(${primaryKeyField})
                .orElseThrow(NotFoundException::new);

        try {
            ${repositoryName}.delete(existing${EntityName});	// Removes the ${EntityName} from being persisted
        } catch (Exception ex) {
            // Return a HTTP status of "500 Internal Server Error" containing the exception message
            return Response
                    .serverError()
                    .encoding(ex.getMessage())
                    .build();
        }

        // Returns an HTTP status "204 No Content" to indicate the resource was deleted
        return Response.noContent().build();

    }

}