#set($createMethodName = "given" + $EntityName + "Data_whenCreate" + $EntityName + "_then" + $EntityName + "IsCreated")
#set($findAllMethodName = "given" + $EntityName + "Exist_whenFindAll" + $EntityName + "s_thenReturn" + $EntityName + "List")
#set($updateMethodName = "givenUpdated" + $EntityName + "Data_whenUpdated" + $EntityName + "_then" + $EntityName + "IsUpdated")
#set($deleteMethodName = "givenExisting" + $EntityName + "Id_whenDelete" + $EntityName + "_then" + $EntityName + "IsDeleted")
#set($findByIdMethodName = "givenExisting" + $EntityName + "Id_whenFind" + $EntityName + "ById_thenReturn" + $EntityName)
#set($findByIdMethodName = "givenExisting" + $EntityName + "Id_whenFind" + $EntityName + "ById_thenReturn" + $EntityName)
#set($entityInstance = "current" + $EntityName)
#set($entityCollectionInstance = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "s" )
#set($restApiBaseUri = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "ResourceUrl" )

import dmit2015.entity.${EntityName};
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.LocalDate;
import java.util.ArrayList;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * This class contains starter code for testing REST API endpoints for CRUD operations using REST-assured.
 *
 * <a href="https://github.com/rest-assured/rest-assured">REST Assured GitHub repo</a>
 * <a href="https://github.com/rest-assured/rest-assured/wiki/Usage">REST Assured Usage</a>
 * <a href="http://www.mastertheboss.com/jboss-frameworks/resteasy/restassured-tutorial">REST Assured Tutorial</a>
 * <a href="https://hamcrest.org/JavaHamcrest/tutorial">Hamcrest Tutorial</a>
 * <a href="https://github.com/FasterXML/jackson-databind">Jackson Data-Binding</a>
 *
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ${EntityName}ResourceRestAssuredParameterizedIT {

    final String ${restApiBaseUri} = "${RestApiBaseUri}";

    @BeforeAll
    static void beforeAllTests() {
        // code to execute before all tests in the current test class
    }

    @AfterAll
    static void afterAllTests() {
        // code to execute after all tests in the current test class
    }

    @BeforeEach
    void beforeEachTestMethod() {
        // Code to execute before each test such as creating the test data
    }

    @AfterEach
    void afterEachTestMethod() {
        // code to execute after each test such as deleting the test data
    }

    @Order(1)
    @ParameterizedTest
    @CsvSource(value = {
            "Property1Value, Property2Value, Property3Value",
            "Property1Value, Property2Value, Property3Value",
    }, nullValues = {"null"})
    void ${createMethodName}(String property1, String property2, String property3) throws Exception {
        // Arrange: Set up the initial state
        var ${entityInstance} = new ${EntityName}();
        ${entityInstance}.setProperty1(property1);
        ${entityInstance}.setProperty2(property2);
        ${entityInstance}.setProperty3(property3);

        // Act & Assert
        try (Jsonb jsonb = JsonbBuilder.create()) {
            String jsonBody = jsonb.toJson(${entityInstance});
            given()
                .contentType(ContentType.JSON)
                .body(jsonBody)
            .when()
                .post(${restApiBaseUri})
            .then()
                .statusCode(201)
                .header("location", containsString(${restApiBaseUri}))
            ;
        }
    }

    @Order(2)
    @ParameterizedTest
    @CsvSource(value = {
            "Property1Value, Property2Value, Property3Value",
            "Property1Value, Property2Value, Property3Value",
    }, nullValues = {"null"})
    void ${findByIdMethodName}(String property1, String property2, String property3) throws Exception {
        // Arrange: Set up the initial state
        var ${entityInstance} = new ${EntityName}();
        ${entityInstance}.setProperty1(property1);
        ${entityInstance}.setProperty2(property2);
        ${entityInstance}.setProperty3(property3);

       // Act & Assert
        try (Jsonb jsonb = JsonbBuilder.create()) {
            String jsonBody = jsonb.toJson(${entityInstance});

            Response response = given()
                    .contentType(ContentType.JSON)
                    .body(jsonBody)
                    .when()
                    .post(${restApiBaseUri});
            var postedDataLocation = response.getHeader("location");

            // Act & Assert
            given()
            .when()
                .get(postedDataLocation)
            .then()
                .statusCode(200)
                .body("id", notNullValue())
                .body("property1", equalTo(${entityInstance}.getProperty1()))
                .body("property2", equalTo(${entityInstance}.getProperty2()))
                .body("property3", equalTo(${entityInstance}.getProperty3()))
                ;
        }

    }

    @Order(3)
    @ParameterizedTest
    @CsvSource(value = {
            "Property1Value1, Property2Value1, Property3Value1, Property1Value2, Property2Value2, Property3Value3",
    }, nullValues = {"null"})
    void ${findAllMethodName}(
        String property1Value1, String property2Value1, String property3Value1,
        String property1Value2, String property2Value2, String property3Value2
        ) throws Exception {
        // Arrange: Set up the initial state
        try (Jsonb jsonb = JsonbBuilder.create()) {
            var first${EntityName} = new ${EntityName}();
            first${EntityName}.setProperty1(property1Value1);
            first${EntityName}.setProperty2(property2Value1);
            first${EntityName}.setProperty3(property3Value1);

            given()
                .contentType(ContentType.JSON)
                .body(jsonb.toJson(first${EntityName}))
            .when()
                .post(${restApiBaseUri})
            .then()
                .statusCode(201);

            var last${EntityName} = new ${EntityName}();
            last${EntityName}.setProperty1(property1Value2);
            last${EntityName}.setProperty2(property2Value2);
            last${EntityName}.setProperty3(property3Value2);

            given()
                .contentType(ContentType.JSON)
                .body(jsonb.toJson(last${EntityName}))
            .when()
                .post(${restApiBaseUri})
            .then()
                .statusCode(201);

            // Act & Assert: Perform the action and verify the expected outcome
            given()
            .when()
                .get(${restApiBaseUri})
            .then()
                .statusCode(200)
                .body("size()", greaterThan(0))
                .body("property1", hasItems(first${EntityName}.getProperty1(), last${EntityName}.getProperty1()))
                .body("property2", hasItems(first${EntityName}.getProperty2(), last${EntityName}.getProperty2()))
                .body("property3", hasItems(first${EntityName}.getProperty3(), last${EntityName}.getProperty3()))
                ;

        }

    }

    @Order(4)
    @ParameterizedTest
    @CsvSource(value = {
            "Property1Value1, Property2Value1, Property3Value1, Property1Value2, Property2Value2, Property3Value3",
    }, nullValues = {"null"})
    void ${updateMethodName}(
            String createProperty1Value, String createProperty2Value, String createProperty3Value,
            String updateProperty1Value, String updateProperty2Value, String updateProperty3Value
    ) throws Exception {
        // Arrange: Set up the initial state
        var create${EntityName} = new ${EntityName}();
        create${EntityName}.setProperty1(createProperty1Value);
        create${EntityName}.setProperty2(createProperty2Value);
        create${EntityName}.setProperty3(createProperty3Value);

        var update${EntityName} = new ${EntityName}();
        update${EntityName}.setProperty1(updateProperty1Value);
        update${EntityName}.setProperty2(updateProperty2Value);
        update${EntityName}.setProperty3(updateProperty3Value);

        try (Jsonb jsonb = JsonbBuilder.create()) {
            String createJsonBody = jsonb.toJson(create${EntityName});

            Response response = given()
                    .contentType(ContentType.JSON)
                    .body(createJsonBody)
                    .when()
                    .post(${restApiBaseUri});
            var postedDataLocation = response.getHeader("location");
            Long entityId = Long.parseLong(postedDataLocation.substring(postedDataLocation.lastIndexOf("/") + 1));
            update${EntityName}.setId(entityId);
            // Act & Assert
            String updateJsonBody = jsonb.toJson(update${EntityName});
            given()
                .contentType(ContentType.JSON)
                .body(updateJsonBody)
            .when()
                .put(postedDataLocation)
            .then()
                .statusCode(200)
                .body("id", equalTo(entityId.intValue()))
                .body("property1", equalTo(update${EntityName}.getProperty1()))
                .body("property2", equalTo(update${EntityName}.getProperty2()))
                .body("property3", equalTo(update${EntityName}.getProperty3()))
            ;
        }

    }

    @Order(5)
    @ParameterizedTest
    @CsvSource(value = {
            "Property1Value, Property2Value, Property3Value",
            "Property1Value, Property2Value, Property3Value",
    }, nullValues = {"null"})
    void ${deleteMethodName}(String property1, String property2, String property3) throws Exception {
        // Arrange: Set up the initial state
        var ${entityInstance} = new ${EntityName}();
        ${entityInstance}.setProperty1(property1);
        ${entityInstance}.setProperty2(property2);
        ${entityInstance}.setProperty3(property3);

        try (Jsonb jsonb = JsonbBuilder.create()) {
            String jsonBody = jsonb.toJson(${entityInstance});

            Response response = given()
                    .contentType(ContentType.JSON)
                    .body(jsonBody)
                    .when()
                    .post(${restApiBaseUri});
            var postedDataLocation = response.getHeader("location");

            // Act & Assert
            given()
            .when()
                .delete(postedDataLocation)
            .then()
                .statusCode(204);

            // Verify deletion
            given()
            .when()
                .delete(postedDataLocation)
            .then()
                .statusCode(404);
        }

    }
}