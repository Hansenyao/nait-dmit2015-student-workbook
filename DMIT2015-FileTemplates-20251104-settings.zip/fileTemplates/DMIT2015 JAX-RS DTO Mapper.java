#set($newEntityInstance = "new" + $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) )
#set($repositoryName = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "Repository")

import dmit2015.dto.${EntityName}Dto;
import dmit2015.entity.${EntityName};
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * This MapStruct interface contains methods on how to map a Jakarta Persistence entity to a DTO
 * (Data Transfer Object) and a method on how to map a DTO to a JPA entity.
 *
 * The following code snippets shows how to call that class-level methods.
 * {@snippet :
 * //${EntityName} new${EntityName}Entity = ${EntityName}Mapper.INSTANCE.toEntity(new${EntityName}Dto);
 * //${EntityName}Dto new${EntityName}Dto = ${EntityName}Mapper.INSTANCE.toDto(new${EntityName}Entity);
 * }
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ${EntityName}Mapper {

    ${EntityName}Mapper INSTANCE = Mappers.getMapper( ${EntityName}Mapper.class );

    // You only need to specify property names that are not the same in the source and target.
    // @Mappings({
    //     @Mapping(target = "dtoProperty1Name", source = "entityProperty1Name"),
    //     @Mapping(target = "dtoProperty2Name", source = "entityProperty2Name"),
    //     @Mapping(target = "dtoProperty3Name", source = "entityProperty3Name"),
    // })
    ${EntityName}Dto toDto(${EntityName} entity);

    // You only need to specify property names that are not the same in the source and target.
    // @Mappings({
    //     @Mapping(target = "entityProperty1Name", source = "dtoProperty1Name"),
    //     @Mapping(target = "entityProperty1Name", source = "dtoProperty2Name"),
    //     @Mapping(target = "entityProperty1Name", source = "dtoProperty3Name"),
    // })
    ${EntityName} toEntity(${EntityName}Dto dto);

}