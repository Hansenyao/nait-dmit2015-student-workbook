#set ( $triple_pound = '###' )
$triple_pound Create a new entity
POST ${RestApiBaseUri}
Content-Type: application/json

{
  "propertyName1":"property1Value",
  "propertyName2":"property2Value",
  "propertyName2":"property2Value"
}

$triple_pound GET All entity from REST API endpoint
GET ${RestApiBaseUri}

$triple_pound GET One entity from REST API endpoint
GET ${RestApiBaseUri}/primaryKeyValue

$triple_pound UPDATE entity at the REST API endpoint - will replace all properties with the properties in the request body
PUT ${RestApiBaseUri}/primaryKeyValue
Content-Type: application/json

{
  "propertyName1":"property1Value",
  "propertyName2":"property2Value",
  "propertyName3":"property3Value"
}

$triple_pound DELETE entity at the REST API endpoint
DELETE ${RestApiBaseUri}/primaryKeyValue

$triple_pound Update specific properties of the entity at the REST API endpoint
PATCH ${RestApiBaseUri}/primaryKeyValue
Content-Type: application/json

{
  "propertyName": "propertyValue"
}