#set($createMethodName = "given" + $EntityName + "Data_whenCreate" + $EntityName + "_then" + $EntityName + "IsCreated")
#set($findAllMethodName = "given" + $EntityName + "Exist_whenFindAll" + $EntityName + "s_thenReturn" + $EntityName + "List")
#set($updateMethodName = "givenUpdated" + $EntityName + "Data_whenUpdated" + $EntityName + "_then" + $EntityName + "IsUpdated")
#set($deleteMethodName = "givenExisting" + $EntityName + "Id_whenDelete" + $EntityName + "_then" + $EntityName + "IsDeleted")
#set($findByIdMethodName = "givenExisting" + $EntityName + "Id_whenFind" + $EntityName + "ById_thenReturn" + $EntityName)
#set($findByIdMethodName = "givenExisting" + $EntityName + "Id_whenFind" + $EntityName + "ById_thenReturn" + $EntityName)
#set($entityInstance = "current" + $EntityName)
#set($entityCollectionInstance = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "s" )
#set($restApiBaseUri = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "ResourceUrl" )

import dmit2015.entity.${EntityName};
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import net.datafaker.Faker;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * This class contains starter code for testing REST API endpoints for CRUD operations using REST-assured.
 *
 * <a href="https://github.com/rest-assured/rest-assured">REST Assured GitHub repo</a>
 * <a href="https://github.com/rest-assured/rest-assured/wiki/Usage">REST Assured Usage</a>
 * <a href="http://www.mastertheboss.com/jboss-frameworks/resteasy/restassured-tutorial">REST Assured Tutorial</a>
 * <a href="https://hamcrest.org/JavaHamcrest/tutorial">Hamcrest Tutorial</a>
 * <a href="https://github.com/FasterXML/jackson-databind">Jackson Data-Binding</a>
 *
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ${EntityName}ResourceRestAssuredFakerIT {

    static Faker faker = new Faker();

    final String ${restApiBaseUri} = "${RestApiBaseUri}";

    @BeforeAll
    static void beforeAllTests() {
        // code to execute before all tests in the current test class
    }

    @AfterAll
    static void afterAllTests() {
        // code to execute after all tests in the current test class
    }

    @BeforeEach
    void beforeEachTestMethod() {
        // Code to execute before each test such as creating the test data
    }

    @AfterEach
    void afterEachTestMethod() {
        // code to execute after each test such as deleting the test data
    }

    @Order(1)
    @Test
    void ${createMethodName}() throws Exception {
        // Arrange: Set up the initial state
        var ${entityInstance} = new ${EntityName}();
        // TODO: Set the properties of ${entityInstance}
${entityInstance}.setProperty1(faker.providerName().methodName());
        ${entityInstance}.setProperty2(faker.providerName().methodName());
        ${entityInstance}.setProperty3(faker.providerName().methodName());

        // Act & Assert
        try (Jsonb jsonb = JsonbBuilder.create()) {
            String jsonBody = jsonb.toJson(${entityInstance});
            given()
                .contentType(ContentType.JSON)
                .body(jsonBody)
            .when()
                .post(${restApiBaseUri})
            .then()
                .statusCode(201)
                .header("location", containsString(${restApiBaseUri}))
            ;
        }
    }

    @Order(2)
    @Test
    void ${findByIdMethodName}() throws Exception {
        // Arrange: Set up the initial state
        var ${entityInstance} = new ${EntityName}();
        // TODO: Set the properties of ${entityInstance}
${entityInstance}.setProperty1(faker.providerName().methodName());
        ${entityInstance}.setProperty2(faker.providerName().methodName());
        ${entityInstance}.setProperty3(faker.providerName().methodName());

       // Act & Assert
        try (Jsonb jsonb = JsonbBuilder.create()) {
            String jsonBody = jsonb.toJson(${entityInstance});

            Response response = given()
                    .contentType(ContentType.JSON)
                    .body(jsonBody)
                    .when()
                    .post(${restApiBaseUri});
            var postedDataLocation = response.getHeader("location");

            // Act & Assert
            // TODO: Change property1, property2, property3
            given()
            .when()
                .get(postedDataLocation)
            .then()
                .statusCode(200)
                .body("id", notNullValue())
                .body("property1", equalTo(${entityInstance}.getProperty1()))
                .body("property2", equalTo(${entityInstance}.getProperty2()))
                .body("property3", equalTo(${entityInstance}.getProperty3()))
                ;
        }

    }

    @Order(3)
    @Test
    void ${findAllMethodName}() throws Exception {
        // Arrange: Set up the initial state
        try (Jsonb jsonb = JsonbBuilder.create()) {
            // Post 3 records and verify the 3 records are added
            var ${entityCollectionInstance} = new ArrayList<${EntityName}>();
            for (int index = 0; index < 3; index++) {
                var ${entityInstance} = new ${EntityName}();
                // TODO: Set the properties of ${entityInstance}
${entityInstance}.setProperty1(faker.providerName().methodName());
                ${entityInstance}.setProperty2(faker.providerName().methodName());
                ${entityInstance}.setProperty3(faker.providerName().methodName());

                ${entityCollectionInstance}.add(current${EntityName});

                given()
                        .contentType(ContentType.JSON)
                        .body(jsonb.toJson(${entityCollectionInstance}.get(index)))
                        .when()
                        .post(${restApiBaseUri})
                .then()
                        .statusCode(201);
            }

            // Act & Assert: Perform the action and verify the expected outcome
            // TODO: Change property1, property2, property3
            given()
                    .when()
                    .get(${restApiBaseUri})
            .then()
                    .statusCode(200)
                    .body("size()", greaterThan(0))
                    .body("property1", hasItems(${entityCollectionInstance}.getFirst().getProperty1(), ${entityCollectionInstance}.getLast().getProperty1()))
                    .body("property2", hasItems(${entityCollectionInstance}.getFirst().getProperty2(), ${entityCollectionInstance}.getLast().getProperty2()))
                    .body("property3", hasItems(${entityCollectionInstance}.getFirst().getProperty3(), ${entityCollectionInstance}.getLast().getProperty3()))
                    ;

        }

    }

    @Order(4)
    @Test
    void ${updateMethodName}() throws Exception {
        // Arrange: Set up the initial state
        var create${EntityName} = new ${EntityName}();
        create${EntityName}.setProperty1(faker.providerName().methodName());
        create${EntityName}.setProperty2(faker.providerName().methodName());
        create${EntityName}.setProperty3(faker.providerName().methodName());

        var update${EntityName} = new ${EntityName}();
        update${EntityName}.setProperty1(faker.providerName().methodName());
        update${EntityName}.setProperty2(faker.providerName().methodName());
        update${EntityName}.setProperty2(faker.providerName().methodName());

        try (Jsonb jsonb = JsonbBuilder.create()) {
            String createJsonBody = jsonb.toJson(create${EntityName});

            Response response = given()
                    .contentType(ContentType.JSON)
                    .body(createJsonBody)
                    .when()
                    .post(${restApiBaseUri});
            var postedDataLocation = response.getHeader("location");
            Long entityId = Long.parseLong(postedDataLocation.substring(postedDataLocation.lastIndexOf("/") + 1));
            update${EntityName}.setId(entityId);
            // Act & Assert
            // TODO: Change property1, property2, property3
            String updateJsonBody = jsonb.toJson(update${EntityName});
            given()
                .contentType(ContentType.JSON)
                .body(updateJsonBody)
            .when()
//                .pathParam("id", entityId)
                .put(postedDataLocation)
            .then()
                .statusCode(200)
                .body("id", equalTo(entityId.intValue()))
                .body("property1", equalTo(update${EntityName}.getProperty1()))
                .body("property2", equalTo(update${EntityName}.getProperty2()))
                .body("property3", equalTo(update${EntityName}.getProperty3()))
            ;
        }

    }

    @Order(5)
    @Test
    void ${deleteMethodName}() throws Exception {
        // Arrange: Set up the initial state
        var ${entityInstance} = new ${EntityName}();
        // TODO: Set the properties of ${entityInstance}
${entityInstance}.setProperty1(faker.providerName().methodName());
        ${entityInstance}.setProperty2(faker.providerName().methodName());
        ${entityInstance}.setProperty3(faker.providerName().methodName());

        try (Jsonb jsonb = JsonbBuilder.create()) {
            String jsonBody = jsonb.toJson(${entityInstance});

            Response response = given()
                    .contentType(ContentType.JSON)
                    .body(jsonBody)
                    .when()
                    .post(${restApiBaseUri});
            var postedDataLocation = response.getHeader("location");
            int entityId = Integer.parseInt(postedDataLocation.substring(postedDataLocation.lastIndexOf("/") + 1));

            // Act & Assert
            given()
//                .pathParam("id", entityId)
            .when()
                .delete(postedDataLocation)
            .then()
                .statusCode(204);

            // Verify deletion
            given()
            .when()
                .delete(postedDataLocation)
            .then()
                .statusCode(404);
        }

    }

}