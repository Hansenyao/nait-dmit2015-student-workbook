#set($entityInstance = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) )
#set($repositoryName = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "Repository")
#set($primaryKeyGetter = "get" + $primaryKeyField.substring(0, 1).toUpperCase() + $primaryKeyField.substring(1) + "()")
#set($findAllMethodName = "findAll" + $EntityName + "s")
#set($createMethodName = "create" + $EntityName)
#set($updateMethodName = "update" + $EntityName)
#set($deleteMethodName = "delete" + $EntityName)
#set($findByIdMethodName = "find" + $EntityName + "ById")

import common.validation.JavaBeanValidator;
import dmit2015.entity.${EntityName};
import dmit2015.repository.${EntityName}Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.OptimisticLockException;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;

import java.net.URI;

/**
 * This Jakarta RESTful Web Services root resource class provides common REST API endpoints to
 * perform CRUD operations on Jakarta Persistence entity.
 */
@ApplicationScoped
@Path("${EntityName}s")	                // All methods of this class are associated this URL path
@Consumes(MediaType.APPLICATION_JSON)	// All methods this class accept only JSON format data
@Produces(MediaType.APPLICATION_JSON)	// All methods returns data that has been converted to JSON format
public class ${EntityName}Resource {

    @Inject
    private ${EntityName}Repository ${repositoryName};

    @GET	// This method only accepts HTTP GET requests.
    public Response ${findAllMethodName}${EntityName}s() {
        return Response.ok(${repositoryName}.findAll()).build();
    }

    @Path("{id}")
    @GET	// This method only accepts HTTP GET requests.
    public Response find${EntityName}ById(@PathParam("id") ${PrimaryKeyDataType} ${primaryKeyField}) {
       ${EntityName} existing${EntityName} = ${repositoryName}.findById(${primaryKeyField}).orElseThrow(NotFoundException::new);

       return Response.ok(existing${EntityName}).build();
    }

    @POST	// This method only accepts HTTP POST requests.
    public Response ${createMethodName}${EntityName}(${EntityName} new${EntityName}, @Context UriInfo uriInfo) {

        String errorMessage = JavaBeanValidator.validateBean(new${EntityName});
        if (errorMessage != null) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(errorMessage)
                    .build();
        }

        try {
            // Persist the new ${EntityName} into the database
            ${repositoryName}.add(new${EntityName});
        } catch (Exception ex) {
            // Return a HTTP status of "500 Internal Server Error" containing the exception message
            return Response.
                    serverError()
                    .entity(ex.getMessage())
                    .build();
        }

        // userInfo is injected via @Context parameter to this method
        URI location = uriInfo.getAbsolutePathBuilder()
                .path(String.valueOf(new${EntityName}.${primaryKeyGetter}))
                .build();

        // Set the location path of the new entity with its identifier
        // Returns an HTTP status of "201 Created" if the ${EntityName} was successfully persisted
        return Response
                .created(location)
                .build();
    }

    @PUT 			// This method only accepts HTTP PUT requests.
    @Path("{id}")	// This method accepts a path parameter and gives it a name of id
    public Response ${updateMethodName}${EntityName}(@PathParam("id") ${PrimaryKeyDataType} id, ${EntityName} updated${EntityName}) {
        if (!id.equals(updated${EntityName}.${primaryKeyGetter})) {
            throw new BadRequestException();
        }

        String errorMessage = JavaBeanValidator.validateBean(updated${EntityName});
        if (errorMessage != null) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(errorMessage)
                    .build();
        }

        ${EntityName} existing${EntityName} = ${repositoryName}
                .findById(id)
                .orElseThrow(NotFoundException::new);
        // TODO: copy properties from the updated entity to the existing entity such as copy the version property shown below
        existing${EntityName}.setVersion(updated${EntityName}.getVersion());

        try {
            ${repositoryName}.update(existing${EntityName});
        } catch (OptimisticLockException ex) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("The data you are trying to update has changed since your last read request.")
                    .build();
        } catch (Exception ex) {
            // Return an HTTP status of "500 Internal Server Error" containing the exception message
            return Response.
                    serverError()
                    .entity(ex.getMessage())
                    .build();
        }

        // Returns an HTTP status "200 OK" and include in the body of the response the object that was updated
        return Response.ok(existing${EntityName}).build();
    }

    @DELETE 			// This method only accepts HTTP DELETE requests.
    @Path("{id}")	// This method accepts a path parameter and gives it a name of id
    public Response ${deleteMethodName}(@PathParam("id") ${PrimaryKeyDataType} id) {

         ${EntityName} existing${EntityName} = ${repositoryName}
                .findById(id)
                .orElseThrow(NotFoundException::new);

        try {
            ${repositoryName}.delete(existing${EntityName});	// Removes the ${EntityName} from being persisted
        } catch (Exception ex) {
            // Return a HTTP status of "500 Internal Server Error" containing the exception message
            return Response
                    .serverError()
                    .encoding(ex.getMessage())
                    .build();
        }

        // Returns an HTTP status "204 No Content" to indicated that the resource was deleted
        return Response.noContent().build();
    }

}