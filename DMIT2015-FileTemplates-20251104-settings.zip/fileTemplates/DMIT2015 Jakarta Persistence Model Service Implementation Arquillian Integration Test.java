#set($entityInstance = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) )
#set($serviceInstanceName = $EntityName.substring(0, 1).toLowerCase() + $EntityName.substring(1) + "Service")
#set($primaryKey = $entityInstance + "Id")

import dmit2015.config.ApplicationConfig;
import dmit2015.model.${EntityName};
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.NotSupportedException;
import jakarta.transaction.SystemException;
import jakarta.transaction.UserTransaction;
import net.datafaker.Faker;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.jboss.shrinkwrap.resolver.api.maven.PomEquippedResolveStage;
import org.junit.jupiter.api.*;
import org.jboss.arquillian.junit5.container.annotation.ArquillianTest;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ArquillianTest
public class JakartaPersistence${EntityName}ServiceImplementationArquillianIT { // The class must be declared as public

    static Faker faker = new Faker();

    static String mavenArtifactIdId;

    @Deployment
    public static WebArchive createDeployment() throws IOException, XmlPullParserException {
        PomEquippedResolveStage pomFile = Maven.resolver().loadPomFromFile("pom.xml");
        MavenXpp3Reader reader = new MavenXpp3Reader();
        Model model = reader.read(new FileReader("pom.xml"));
        mavenArtifactIdId = model.getArtifactId();
        final String archiveName = model.getArtifactId() + ".war";
        return ShrinkWrap.create(WebArchive.class,archiveName)
                .addAsLibraries(pomFile.resolve("org.codehaus.plexus:plexus-utils:3.4.2").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("org.hamcrest:hamcrest:3.0").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("org.assertj:assertj-core:3.27.6").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("net.datafaker:datafaker:2.5.1").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("com.h2database:h2:2.3.232").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("com.microsoft.sqlserver:mssql-jdbc:13.2.0.jre11").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("com.oracle.database.jdbc:ojdbc11:23.9.0.25.07").withTransitivity().asFile())
                .addAsLibraries(pomFile.resolve("org.postgresql:postgresql:42.7.7").withTransitivity().asFile())
//                .addAsLibraries(pomFile.resolve("com.mysql:mysql-connector-j:9.2.0").withTransitivity().asFile())
//                .addAsLibraries(pomFile.resolve("org.mariadb.jdbc:mariadb-java-client:3.5.3").withTransitivity().asFile())
                // .addAsLibraries(pomFile.resolve("org.hibernate.orm:hibernate-spatial:6.6.28.Final").withTransitivity().asFile())
                // .addAsLibraries(pomFile.resolve("org.eclipse:yasson:3.0.4").withTransitivity().asFile())
                .addClass(ApplicationConfig.class)
                .addClasses(${EntityName}.class, ${EntityName}Service.class, JakartaPersistence${EntityName}Service.class)
                // TODO Add any additional libraries, packages, classes or resource files required
//                .addAsLibraries(pomFile.resolve("jakarta.platform:jakarta.jakartaee-api:10.0.0").withTransitivity().asFile())
                // .addPackage("dmit2015.entity")
                .addAsResource("META-INF/persistence.xml")
                // .addAsResource(new File("src/test/resources/META-INF/persistence-entity.xml"),"META-INF/persistence.xml")
                .addAsResource("META-INF/beans.xml");
    }

    @Inject
    @Named("jakartaPersistence${EntityName}Service")
    private JakartaPersistence${EntityName}Service ${serviceInstanceName};

    @Resource
    private UserTransaction beanManagedTransaction;

    @BeforeAll
    static void beforeAllTests() {
        // code to execute before all tests in the current test class
    }

    @AfterAll
    static void afterAllTests() {
        // code to execute after all tests in the current test class
    }

    @BeforeEach
    void beforeEachTestMethod() throws SystemException, NotSupportedException {
        // Start a new transaction
        beanManagedTransaction.begin();
    }

    @AfterEach
    void afterEachTestMethod() throws SystemException {
        // Rollback the transaction
        beanManagedTransaction.rollback();
    }

    @Order(1)
    @Test
    void givenNewEntity_whenAddEntity_thenEntityIsAdded() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);

        // Act
        ${serviceInstanceName}.create${EntityName}(new${EntityName});

        // Assert
        assertThat(new${EntityName}.getId())
            .isNotNull();

    }

    @Order(2)
    @Test
    void givenExistingId_whenFindById_thenReturnEntity() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);

        // Act
        new${EntityName} = ${serviceInstanceName}.create${EntityName}(new${EntityName});

        // Assert
        Optional<${EntityName}> optional${EntityName} = ${serviceInstanceName}.get${EntityName}ById(new${EntityName}.getId());
        assertThat(optional${EntityName}.isPresent())
            .isTrue();
            // Assert
        var existing${EntityName} = optional${EntityName}.orElseThrow();
        assertThat(existing${EntityName})
            .usingRecursiveComparison()
            // .ignoringFields("field1", "field2")
            .isEqualTo(new${EntityName});

    }

    @Order(3)
    @Test
    void givenExistingEntity_whenUpdatedEntity_thenEntityIsUpdated() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);

        new${EntityName} = ${serviceInstanceName}.create${EntityName}(new${EntityName});
        // TODO: change the values of all properties
        //new${EntityName}.setProperty1(faker.providerName().methodName());
        //new${EntityName}.setProperty2(faker.providerName().methodName());
        //new${EntityName}.setProperty3(faker.providerName().methodName());

        // Act
        ${EntityName} updated${EntityName} = ${serviceInstanceName}.update${EntityName}(new${EntityName});

        // Assert
        Optional<${EntityName}> optional${EntityName} = ${serviceInstanceName}.get${EntityName}ById(updated${EntityName}.getId());
        assertThat(optional${EntityName}.isPresent())
            .isTrue();
        var existing${EntityName} = optional${EntityName}.orElseThrow();
        assertThat(existing${EntityName})
            .usingRecursiveComparison()
            // .ignoringFields("field1", "field2")
            .isEqualTo(new${EntityName});

    }

    @Order(4)
    @Test
    void givenExistingId_whenDeleteEntity_thenEntityIsDeleted() {
        // Arrange
        ${EntityName} new${EntityName} = ${EntityName}.of(faker);
        new${EntityName} = ${serviceInstanceName}.create${EntityName}(new${EntityName});
        // Act
        ${serviceInstanceName}.delete${EntityName}ById(new${EntityName}.getId());
        // Assert
        Optional<${EntityName}> optional${EntityName} = ${serviceInstanceName}.get${EntityName}ById(new${EntityName}.getId());
        assertThat(optional${EntityName}.isPresent())
            .isFalse();

    }

    @Order(5)
    @ParameterizedTest
    @CsvSource({"10"})
    void givenMultipleEntity_whenFindAll_thenReturnEntityList(int expectedRecordCount) {
        // Arrange: Set up the initial state

        // Delete all existing data
        assertThat(${serviceInstanceName}).isNotNull();
        ${serviceInstanceName}.deleteAll${EntityName}s();
        // Generate expectedRecordCount number of fake data
        ${EntityName} firstExpected${EntityName} = null;
        ${EntityName} lastExpected${EntityName} = null;
        for (int counter = 1; counter <= expectedRecordCount; counter++) {
            ${EntityName} current${EntityName} = ${EntityName}.of(faker);
            if (counter == 1) {
                firstExpected${EntityName} = current${EntityName};
            } else if (counter == expectedRecordCount) {
                lastExpected${EntityName} = current${EntityName};
            }

            new${EntityName} = ${serviceInstanceName}.create${EntityName}(current${EntityName});
        }

        // Act: Perform the action to be tested
        List<${EntityName}> ${entityInstance}List = ${serviceInstanceName}.getAll${EntityName}s();

        // Assert: Verify the expected outcome
        assertThat(${entityInstance}List.size())
            .isEqualTo(expectedRecordCount);

        // Get the first entity and compare with expected results
        var firstActual${EntityName} = ${entityInstance}List.getFirst();
        assertThat(firstActual${EntityName})
            .usingRecursiveComparison()
            // .ignoringFields("field1", "field2")
            .isEqualTo(firstExpected${EntityName});
        // Get the last entity and compare with expected results
        var lastActual${EntityName} = ${entityInstance}List.getLast();
        assertThat(lastActual${EntityName})
            .usingRecursiveComparison()
            // .ignoringFields("field1", "field2")
            .isEqualTo(lastExpected${EntityName});

    }

    @Order(6)
    @ParameterizedTest
     // TODO Change the value below
    @CsvSource(value = {
            "Invalid Property1Value, Property2Value, Property3Value, ExpectedExceptionMessage",
            "Property1Value, Invalid Property2Value, Property3Value, ExpectedExceptionMessage",
    }, nullValues = {"null"})
    void givenEntityWithValidationErrors_whenAddEntity_thenThrowException(
        String property1,
        String property2,
        String property3,
        String expectedExceptionMessage
    ) {
        // Arrange
        ${EntityName} new${EntityName} = new ${EntityName}();
        // TODO uncomment below and set each property of ${EntityName} using parameter values
        // new${EntityName}.setProperty1(property1);
        // new${EntityName}.setProperty2(property2);
        // new${EntityName}.setProperty3(property3);

        try {
            // Act
            ${serviceInstanceName}.create${EntityName}(new${EntityName});
            fail("An bean validation constraint should have been thrown");
        } catch (Exception ex) {
            // Assert
            assertThat(ex)
                .hasMessageContaining(expectedExceptionMessage);
        }

    }

}