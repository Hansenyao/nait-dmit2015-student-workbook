#set($beanName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($messagesId = "messages")
package ${PACKAGE_NAME};

import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.omnifaces.util.Messages;

/**
 * View-scoped backing bean: lives across postbacks on the SAME view.
 * Destroyed when navigating away to a different view.
 */
@Named("${beanName}View")
@ViewScoped // Survives postbacks (including AJAX) on this view; Serializable required
public class ${NAME}View implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final Logger LOG = Logger.getLogger(${NAME}View.class.getName());

    // --- Optional scaffolding (uncomment if you need it in class) ---
    // // Example of a selected row for a form
    // // private ${NAME} selected${NAME};
    // //
    // // If you inject services, keep them light or mark as transient
    // // @Inject
    // // private transient ${NAME}Service ${beanName}Service;

    @PostConstruct // Runs after @Inject fields are initialized (once per view instance)
    public void init() {
        // Initialize view state (avoid heavy I/O here)
        // Example: preload data for this view
        // selected${NAME} = new ${NAME}();
    }

    public void onSubmit() {
        try {
            // TODO: handle action (e.g., call a service, update state, etc.)
            // Messages.addGlobalInfo("Saved.");
        } catch (Exception ex) {
            handleException(ex, "Unable to process your request.");
        }
    }

    public void onClear() {
        // Reset view state

        // selected${NAME} = null;
    }

    /**
     * Log server-side and show a concise root-cause chain in the UI.
     * Assumes the page includes <p:messages id="error" />.
     */
    protected void handleException(Throwable ex, String userMessage) {
        LOG.log(Level.SEVERE, userMessage != null ? userMessage : "Unhandled error", ex);

        StringBuilder details = new StringBuilder();
        Throwable t = ex;
        while (t != null) {
            String msg = t.getMessage();
            if (msg != null && !msg.isBlank()) {
                details.append(t.getClass().getSimpleName())
                       .append(": ")
                       .append(msg);
                if (t.getCause() != null) details.append("  Caused by: ");
            }
            t = t.getCause();
        }

        try {
            Messages.create(userMessage != null ? userMessage : "An unexpected error occurred.")
                    .detail(details.toString())
                    .error()
                    .add("${messagesId}"); 
        } catch (Throwable ignored) {
            // No FacesContext available; skip UI message safely.
        }
    }
}