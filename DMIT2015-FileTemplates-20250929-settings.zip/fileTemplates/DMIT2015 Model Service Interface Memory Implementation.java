#set($modelInstanceName = $ModelClass.substring(0, 1).toLowerCase() + $ModelClass.substring(1))
#set($cdiInstanceName = "memory" + $ModelClass + "Service" )
#set($collectionInstanceName = $ModelClass.substring(0, 1).toLowerCase() + $ModelClass.substring(1) + "s")
#set($currentModelInstance = "current" + $ModelClass )

import dmit2015.model.${ModelClass};
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.datafaker.Faker;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.random.RandomGenerator;

@Named("${cdiInstanceName}")
@ApplicationScoped
public class Memory${ModelClass}Service implements ${ModelClass}Service {

    private final List<${ModelClass}> ${collectionInstanceName} = new CopyOnWriteArrayList<>();

    @PostConstruct
    public void init() {

        var faker = new Faker();
        for(int counter = 1; counter <= ${NumberOfObjectsToGenerate}; counter++) {
            var ${currentModelInstance} = ${ModelClass}.of(faker);           
            ${collectionInstanceName}.add(${currentModelInstance});
        }

    }

    @Override
    public ${ModelClass} create${ModelClass}(${ModelClass} ${modelInstanceName}) {
        Objects.requireNonNull(${modelInstanceName}, "${ModelClass} to create must not be null");

         // Assign a fresh id on create to ensure uniqueness (ignore any incoming id)
        ${ModelClass} stored = ${ModelClass}.copyOf(${modelInstanceName});
        stored.setId(UUID.randomUUID().toString());
        ${collectionInstanceName}.add(stored);

        // Return a defensive copy
        return ${ModelClass}.copyOf(stored);
    }

    @Override
    public Optional<${ModelClass}> get${ModelClass}ById(String id) {
        Objects.requireNonNull(id, "id must not be null");

        return ${collectionInstanceName}.stream()
                .filter(${currentModelInstance} -> ${currentModelInstance}.getId().equals(id))
                .findFirst()
                .map(${ModelClass}::copyOf); // return a copy to avoid external mutation

    }

    @Override
    public List<${ModelClass}> getAll${ModelClass}s() {
        // Unmodifiable snapshot of copies
        return ${collectionInstanceName}.stream().map(${ModelClass}::copyOf).toList();
    }

    @Override
    public ${ModelClass} update${ModelClass}(${ModelClass} ${modelInstanceName}) {
        Objects.requireNonNull(${modelInstanceName}, "${ModelClass} to update must not be null");
        Objects.requireNonNull(${modelInstanceName}.getId(), "${ModelClass} id must not be null");

        // Find index of existing task by id
        int index = -1;
        for (int i = 0; i < ${collectionInstanceName}.size(); i++) {
            if (${collectionInstanceName}.get(i).getId().equals(${modelInstanceName}.getId())) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            throw new NoSuchElementException("Could not find Task with id: " + ${modelInstanceName}.getId());
        }

        // Replace stored item with a copy (preserve id)
        ${ModelClass} stored = ${ModelClass}.copyOf(${modelInstanceName});
        ${collectionInstanceName}.set(index, stored);

        return ${ModelClass}.copyOf(stored);
    }

    @Override
    public void delete${ModelClass}ById(String id) {
        Objects.requireNonNull(id, "id must not be null");

        boolean removed = ${collectionInstanceName}.removeIf(${currentModelInstance} -> id.equals(${currentModelInstance}.getId()));
        if (!removed) {
            throw new NoSuchElementException("Could not find Task with id: " + id);
        }
    }
}
