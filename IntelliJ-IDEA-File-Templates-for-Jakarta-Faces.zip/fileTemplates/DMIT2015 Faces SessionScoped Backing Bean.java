#set($beanName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($messagesId = "messages")
package ${PACKAGE_NAME};

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.omnifaces.util.Messages;

/**
 * Session-scoped backing bean: per-user state that persists for the HTTP session.
 * Implements Serializable for passivation.
 */
@Named("${beanName}Session")
@SessionScoped // Lives for the user's session; store only per-user state
public class ${NAME}Session implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final Logger LOG = Logger.getLogger(${NAME}Session.class.getName());

    // --- Minimal demo state ---
    // Example: a per-user counter to illustrate session scope
    private int counter;

    public int getCounter() {
        return counter;
    }

    public void increment() {
        counter++;
        Messages.addGlobalInfo("SessionScoped current count: {0}", counter);
    }

    // --- Optional scaffolding patterns (uncomment if needed) ---
    // // @Getter @Setter (if you use Lombok)
    // // private ${NAME} selected${NAME};
    //
    // // Read-only data model for tables
    // // private Collection<${NAME}> ${beanName}s = Collections.emptyList();
    //
    // // Prefer injecting a service (CDI proxies are Serializable)
    // // @Inject
    // // private transient ${NAME}Service ${beanName}Service;

    @PostConstruct // Runs once per session for this bean, after DI completes
    public void init() {
        // Initialize per-user defaults (lightweight!). Avoid heavy IO here.
        // this.${beanName}s = ${beanName}Service.findAll(); // example
    }

    public void onSubmit() {
        try {
            // TODO: handle action (call service, update session state, etc.)
            // Messages.addGlobalInfo("Saved.");
        } catch (Exception ex) {
            handleException(ex, "Unable to process your request.");
        }
    }

    public void onSelected() {
        try {
            // TODO: handle row selection, etc.
        } catch (Exception ex) {
            handleException(ex, "Unable to select item.");
        }
    }

    public void onClear() {
        // Reset per-user state
        counter = 0;
        // selected${NAME} = null;
        // ${beanName}s = Collections.emptyList();
    }

    /**
     * Log server-side and show a concise root-cause chain in the UI.
     * Assumes <p:messages id="error" /> is present in the page.
     */
    protected void handleException(Throwable ex, String userMessage) {
        LOG.log(Level.SEVERE, userMessage, ex);

        StringBuilder details = new StringBuilder();
        Throwable t = ex;
        while (t != null) {
            String msg = t.getMessage();
            if (msg != null && !msg.isBlank()) {
                details.append(t.getClass().getSimpleName())
                       .append(": ")
                       .append(msg);
                if (t.getCause() != null) details.append("  Caused by: ");
            }
            t = t.getCause();
        }

        try {
            Messages.create(userMessage != null ? userMessage : "An unexpected error occurred.")
                    .detail(details.toString())
                    .error()
                    .add("${messagesId}"); 
        } catch (Throwable ignored) {
            // No FacesContext available; skip UI notification safely.
        }
    }
}
