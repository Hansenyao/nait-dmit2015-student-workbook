#set($beanName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($messagesId = "messages")
package ${PACKAGE_NAME};

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.omnifaces.util.Messages;

/**
 * Request-scoped backing bean: new instance per HTTP request.
 * Use for simple actions/data that don't need to persist after the response.
 */
@Named("${beanName}Request")
@RequestScoped // New instance per HTTP request; no Serializable required
public class ${NAME}Request {

    private static final Logger LOG = Logger.getLogger(${NAME}Request.class.getName());

    // --- Minimal demo state (resets every request) ---
    private int counter;

    public int getCounter() {
        return counter;
    }

    public void increment() {
        counter++;
        Messages.addGlobalInfo("RequestScoped current count: {0}", counter);
    }

    @PostConstruct // Runs after @Inject is completed, once per request for this bean
    public void init() {
        // Keep this light; heavy work here runs every request.
        // Example: initialize defaults derived from request context.
    }

    public void onSubmit() {
        try {
            // TODO: handle action for this request (validate, call service, etc.)
            // Messages.addGlobalInfo("Processed.");
        } catch (Exception ex) {
            handleException(ex, "Unable to process your request.");
        }
    }

    public void onClear() {
        // Reset request fields (mostly illustrative; a new request creates a new bean anyway)
        input = 0;
    }

    /**
     * Log server-side and show a concise root-cause chain in the UI.
     * Assumes the page includes <p:messages id="error" />.
     */
    protected void handleException(Throwable ex, String userMessage) {
        LOG.log(Level.SEVERE, userMessage != null ? userMessage : "Unhandled error", ex);

        StringBuilder details = new StringBuilder();
        Throwable t = ex;
        while (t != null) {
            String msg = t.getMessage();
            if (msg != null && !msg.isBlank()) {
                details.append(t.getClass().getSimpleName())
                       .append(": ")
                       .append(msg);
                if (t.getCause() != null) details.append("  Caused by: ");
            }
            t = t.getCause();
        }

        try {
            Messages.create(userMessage != null ? userMessage : "An unexpected error occurred.")
                    .detail(details.toString())
                    .error()
                    .add("${messagesId}"); 
        } catch (Throwable ignored) {
            // No FacesContext available; skip UI notification safely.
        }
    }
}
